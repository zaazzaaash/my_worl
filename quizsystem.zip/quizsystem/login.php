<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] === 'admin') {
            header("Location: admin.php");
        } else {
            header("Location: index.php");
        }
        exit();
    } else {
        echo "<script>alert('Invalid email or password');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login</title>
<link rel="stylesheet" href="style.css">
<style>
/* Extra tweaks for bigger input boxes and buttons matching your quiz design */
.container {
  max-width: 400px;
  margin: 100px auto;
  padding: 40px;
  background: rgba(0, 242, 255, 0.08);
  border: 2px solid #00f2ff;
  border-radius: 20px;
  text-align: center;
  box-shadow: 0 0 20px #00f2ff;
  color: #00f2ff;
}

.container h1 {
  font-size: 2rem;
  margin-bottom: 25px;
  color: #00f2ff;
}

.container input {
  width: 95%;
  padding: 15px;
  margin: 10px 0;
  font-size: 1.1rem;
  border: 2px solid #00f2ff;
  border-radius: 10px;
  background: rgba(0, 242, 255, 0.1);
  color: #00f2ff;
  outline: none;
}

.container input::placeholder {
  color: #00f2ff;
}

.container button {
  width: 95%;
  padding: 15px;
  font-size: 1.1rem;
  border: 2px solid #00f2ff;
  border-radius: 10px;
  background: #00f2ff;
  color: #000;
  font-weight: bold;
  cursor: pointer;
  transition: 0.3s;
  margin-top: 10px;
}

.container button:hover {
  background: rgba(0, 242, 255, 0.6);
}

.container p {
  margin-top: 15px;
  font-size: 0.95rem;
  color: #00f2ff;
}

.container a {
  color: #00f2ff;
  text-decoration: none;
}

.container a:hover {
  text-decoration: underline;
}
</style>
</head>
<body>
<div class="container float">
  <h1>Login</h1>
  <form method="POST">
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <button type="submit">Login</button>
  </form>
  <p>Don't have an account? <a href="register.php">Register</a></p>
</div>
</body>
</html>
