// script.js
const questions = [
  { q: "What does HTML stand for?", choices: ["Hyper Tool Markup Language", "Hypertext Markup Language", "HighText Machine Language"], a: "Hypertext Markup Language" },
  { q: "Which tag is used to link CSS?", choices: ["style", "link", "css"], a: "link" },
  { q: "Which property sets text color in CSS?", choices: ["font-color", "color", "text-style"], a: "color" },
  { q: "What keyword declares a variable in JS?", choices: ["var", "let", "const"], a: "let" },
  { q: "Which HTML tag adds JavaScript?", choices: ["js", "script", "code"], a: "script" },
  { q: "What does CSS stand for?", choices: ["Creative Style System", "Cascading Style Sheets", "Computer Styling Structure"], a: "Cascading Style Sheets" },
  { q: "Which attribute sets an image source in HTML?", choices: ["link", "src", "href"], a: "src" },
  { q: "Which property controls font size in CSS?", choices: ["font", "font-size", "text-size"], a: "font-size" },
  { q: "Which symbol is used for comments in JS?", choices: ["<!-- -->", "//", "/* */"], a: "//" },
  { q: "Which tag creates a hyperlink in HTML?", choices: ["a", "link", "href"], a: "a" }
];

let current = 0;
let score = 0;

const questionEl = document.getElementById("question");
const choicesEl = document.getElementById("choices");
const startBtn = document.getElementById("startBtn");
const feedbackEl = document.getElementById("feedback");
const progressEl = document.getElementById("progress");
const scoreEl = document.getElementById("score");
const feedbackSection = document.getElementById("feedback-section");
const thanksMsg = document.getElementById("thanksMsg");

function startQuiz() {
  current = 0;
  score = 0;
  feedbackEl.textContent = "";
  scoreEl.textContent = "";
  feedbackSection.style.display = "none";
  startBtn.style.display = "none";
  showQuestion();
}

function showQuestion() {
  const q = questions[current];
  questionEl.textContent = q.q;
  progressEl.textContent = `Question ${current + 1} of ${questions.length}`;
  choicesEl.innerHTML = "";

  q.choices.forEach(choice => {
    const btn = document.createElement("button");
    btn.classList.add("choice-btn");
    btn.textContent = choice;
    btn.addEventListener("click", () => checkAnswer(choice));
    choicesEl.appendChild(btn);
  });
}

function checkAnswer(selected) {
  const correct = questions[current].a;

  if (selected.toLowerCase() === correct.toLowerCase()) {
    feedbackEl.textContent = "✅ Correct!";
    score++;
  } else {
    feedbackEl.textContent = `❌ Wrong! The correct answer is: ${correct}`;
  }

  current++;
  if (current < questions.length) {
    setTimeout(() => {
      feedbackEl.textContent = "";
      showQuestion();
    }, 1500);
  } else {
    endQuiz();
  }
}

function endQuiz() {
  questionEl.textContent = "🎉 You finished the quiz!";
  choicesEl.innerHTML = "";
  progressEl.textContent = "";
  feedbackEl.textContent = "";
  scoreEl.textContent = `Your score: ${score} / ${questions.length}`;
  startBtn.style.display = "inline-block";
  feedbackSection.style.display = "flex";
}

startBtn.addEventListener("click", startQuiz);
