<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);

    // Check if email exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<script>alert('Email already exists');</script>";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (fullname, email, password, role) VALUES (?, ?, ?, 'student')");
        $stmt->bind_param("sss", $fullname, $email, $password);
        if ($stmt->execute()) {
            echo "<script>alert('Registration successful!'); window.location='login.php';</script>";
            exit();
        } else {
            echo "<script>alert('Registration failed!');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Register</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .container {
      max-width: 400px;
      margin: 60px auto;
      padding: 40px;
      background: rgba(255,255,255,0.1);
      border-radius: 15px;
      text-align: center;
      backdrop-filter: blur(10px);
      color: white;
    }
    .container h1 { font-size: 2rem; margin-bottom: 25px; }
    .container input {
      width: 90%; padding: 15px; margin: 10px 0; font-size: 1.1rem; border: none; border-radius: 8px; outline: none; background: #2c2c2c; color: white;
    }
    .container button {
      width: 95%; padding: 15px; font-size: 1.1rem; border: none; border-radius: 8px; background: #4c57af; color: white; cursor: pointer; transition: 0.3s; margin-top: 10px;
    }
    .container button:hover { background: #3f4b9e; }
    .container p { margin-top: 15px; font-size: 0.95rem; color: #ccc; }
    .container a { color: #7a86ff; text-decoration: none; }
    .container a:hover { text-decoration: underline; }
  </style>
</head>
<body>
<div class="container">
  <h1>Register</h1>
  <form method="POST">
    <input type="text" name="fullname" placeholder="Full Name" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <button type="submit">Register</button>
  </form>
  <p>Already have an account? <a href="login.php">Login</a></p>
</div>
</body>
</html>
