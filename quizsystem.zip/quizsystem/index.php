<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Profile + Quiz</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <!-- Floating Header Bar -->
  <div class="quiz-header">
    <div class="user">Welcome, <?php echo htmlspecialchars($_SESSION['fullname']); ?>!</div>
    <form action="logout.php" method="post" style="margin:0;">
      <button class="logout" type="submit">Logout</button>
    </form>
  </div>

  <div class="container float">
    <!-- Fixed Profile Picture -->
    <div class="profile">
      <img src="c71dd7bb-7aa5-4c80-a05c-052c7357b429.jpg" alt="Profile Picture" class="profile-pic">
    </div>

    <h1>HTML • CSS • JS Quiz</h1>

    <div id="quiz-box" class="quiz-box">
      <p id="progress" class="progress"></p>
      <p id="question">Click "Start" to begin the quiz!</p>
      <div id="choices" class="choices"></div>
      <button id="startBtn">Start</button>
      <p id="feedback" class="feedback"></p>
      <p id="score" class="score"></p>

      <!-- Feedback section -->
      <div id="feedback-section" class="feedback-section" style="display:none;">
        <h3>📝 Your Feedback</h3>
        <form id="feedbackForm" method="POST" action="save_feedback.php">
          <textarea id="userFeedback" name="feedback" placeholder="Write your feedback here..."></textarea>
          <button type="submit" id="submitFeedback">Submit Feedback</button>
        </form>
        <p id="thanksMsg" class="thanks"></p>
      </div>
    </div>
  </div>

  <script src="script.js"></script>
</body>
</html>
