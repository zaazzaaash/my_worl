<?php
session_start();
include 'db.php';

// Check if admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Get all users
$users = $conn->query("SELECT id, fullname, email, role FROM users");

// Get scores safely (without assuming quiz_title column)
$scores = $conn->query("
    SELECT u.fullname, s.score, s.created_at
    FROM scores s
    JOIN users u ON s.user_id = u.id
    ORDER BY s.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Panel</title>
<link rel="stylesheet" href="style.css">
<style>
.container {
    max-width: 900px;
    margin: 100px auto;
    padding: 40px;
    background: rgba(0, 242, 255, 0.08);
    border: 2px solid #00f2ff;
    border-radius: 20px;
    box-shadow: 0 0 20px #00f2ff;
    color: #00f2ff;
}
h1, h2 {
    color: #00f2ff;
    text-shadow: 0 0 10px #00f2ff;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 30px;
}
table th, table td {
    border: 1px solid #00f2ff;
    padding: 10px;
    text-align: left;
}
table th {
    background: rgba(0, 242, 255, 0.2);
}
a.logout {
    display: inline-block;
    padding: 10px 15px;
    background: #ff4d4d;
    color: #fff;
    border-radius: 10px;
    text-decoration: none;
    margin-top: 20px;
}
a.logout:hover {
    background: #ff7070;
}
</style>
</head>
<body>
<div class="container float">
    <h1>Welcome, Admin <?php echo $_SESSION['fullname']; ?></h1>

    <h2>All Users</h2>
    <table>
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr>
        <?php while ($row = $users->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['fullname'] ?></td>
            <td><?= $row['email'] ?></td>
            <td><?= $row['role'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <h2>Quiz Scores</h2>
    <table>
        <tr><th>Name</th><th>Score</th><th>Date</th></tr>
        <?php while ($row = $scores->fetch_assoc()): ?>
        <tr>
            <td><?= $row['fullname'] ?></td>
            <td><?= $row['score'] ?></td>
            <td><?= $row['created_at'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <a href="logout.php" class="logout">Logout</a>
</div>
</body>
</html>
