<?php
$conn = new mysqli("localhost", "root", "", "quizsystem");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
