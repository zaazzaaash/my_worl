<?php
// save_feedback.php
session_start();

// ensure file is in same folder and db.php exists
if (!file_exists('db.php')) {
    // helpful error for debugging
    die("Missing db.php — make sure db.php is in the same folder as save_feedback.php");
}
include 'db.php'; // expects $conn (mysqli) from db.php

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit();
}

// simple validation
$feedback = trim($_POST['feedback'] ?? '');
if ($feedback === '') {
    echo "<script>alert('⚠️ Please write something before submitting.'); window.location='index.php';</script>";
    exit();
}

// get user id if logged in (index.php requires login, but double-check)
$user_id = $_SESSION['user_id'] ?? null;

if ($user_id) {
    // insert with user_id
    $stmt = $conn->prepare("INSERT INTO feedbacks (user_id, feedback) VALUES (?, ?)");
    if (!$stmt) {
        // debug error
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("is", $user_id, $feedback);
} else {
    // insert without user_id
    $stmt = $conn->prepare("INSERT INTO feedbacks (user_id, feedback) VALUES (NULL, ?)");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("s", $feedback);
}

if ($stmt->execute()) {
    // success: show a message and return to quiz page
    echo "<script>alert('✅ Thank you for your feedback!'); window.location='index.php';</script>";
    exit();
} else {
    // failure
    echo "<script>alert('Error saving feedback: " . addslashes($stmt->error) . "'); window.location='index.php';</script>";
    exit();
}
