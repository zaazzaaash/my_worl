<?php
include 'db.php';

$fullname = 'Admin User';
$email = 'admin@quiz.com';
$password = password_hash('admin123', PASSWORD_DEFAULT); // password = admin123
$role = 'admin';

// Check kung may existing admin
$check = $conn->prepare("SELECT * FROM users WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    echo "Admin account already exists!";
} else {
    $stmt = $conn->prepare("INSERT INTO users (fullname, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $fullname, $email, $password, $role);
    $stmt->execute();
    echo "Admin account created successfully!";
}
