<?php
include 'db.php';

// Hash a new password for the admin
$admin_password = password_hash("admin123", PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE users SET password=? WHERE email='admin@quiz.com'");
$stmt->bind_param("s", $admin_password);
$stmt->execute();

echo "Admin password updated!";
?>
