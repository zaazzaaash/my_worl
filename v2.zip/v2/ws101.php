<?php include 'includes/header.php'; ?>
  <section class="panel">
    <h2 style="margin:0 0 12px 0">WS101 Project</h2>
    <div class="iframe-wrap panel">
      <iframe src="ws101/" title="WS101 Project - project"></iframe>
    </div>
    <p style="color:var(--muted);margin-top:12px">If the embedded app requires sessions or headers, open the project directly (e.g., <code>ws101/</code>)</p>
  </section>
<?php include 'includes/footer.php'; ?>