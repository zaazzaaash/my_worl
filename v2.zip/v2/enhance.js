
// Add simple scroll reveal for elements with class 'section'
document.addEventListener('DOMContentLoaded', function(){
  // Mobile-friendly dropdown toggle for touch devices
  document.querySelectorAll('.nav-item').forEach(function(item){
    item.addEventListener('click', function(e){
      // if it has a dropdown and clicked target is the link, toggle
      if(window.matchMedia('(max-width:800px)').matches){
        const dd = item.querySelector('.dropdown');
        if(dd){
          e.preventDefault();
          dd.style.display = dd.style.display === 'block' ? 'none' : 'block';
        }
      }
    });
  });

  // Scroll reveal
  const sections = document.querySelectorAll('.section, .card, .hero');
  const obs = new IntersectionObserver((entries)=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        entry.target.classList.add('visible');
      }
    });
  }, {threshold:0.12});
  sections.forEach(s=>obs.observe(s));
});
