<?php include 'includes/header.php'; ?>
  <section class="panel">
    <h2 style="margin:0 0 12px 0">SPT1 Project</h2>
    <div class="iframe-wrap panel">
      <iframe src="spt1/" title="SPT1 Project - project"></iframe>
    </div>
    <p style="color:var(--muted);margin-top:12px">If the embedded app requires sessions or headers, open the project directly (e.g., <code>spt1/</code>)</p>
  </section>
<?php include 'includes/footer.php'; ?>