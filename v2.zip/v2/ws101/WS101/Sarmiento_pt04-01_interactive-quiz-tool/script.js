const questions = [
  { q: "What does HTML stand for?", a: "Hypertext Markup Language" },
  { q: "Which tag is used to link CSS?", a: "link" },
  { q: "Which property sets text color in CSS?", a: "color" },
  { q: "What keyword declares a variable in JS?", a: "let" },
  { q: "Which HTML tag adds JavaScript?", a: "script" },
  { q: "What does CSS stand for?", a: "Cascading Style Sheets" },
  { q: "Which attribute sets an image source in HTML?", a: "src" },
  { q: "Which property controls font size in CSS?", a: "font-size" },
  { q: "Which symbol is used for comments in JS?", a: "//" },
  { q: "Which tag creates a hyperlink in HTML?", a: "a" }
];

let current = 0;
let score = 0;

const questionEl = document.getElementById("question");
const progressEl = document.getElementById("progress");
const feedbackEl = document.getElementById("feedback");
const scoreEl = document.getElementById("score");

const startBtn = document.getElementById("startBtn");
const answerInput = document.getElementById("answerInput");
const submitBtn = document.getElementById("submitBtn");

const feedbackSection = document.getElementById("feedback-section");
const submitFeedbackBtn = document.getElementById("submitFeedback");
const userFeedback = document.getElementById("userFeedback");
const thanksMsg = document.getElementById("thanksMsg");

function startQuiz() {
  current = 0;
  score = 0;
  feedbackEl.textContent = "";
  scoreEl.textContent = "";
  feedbackSection.style.display = "none";

  startBtn.style.display = "none";
  answerInput.style.display = "inline-block";
  submitBtn.style.display = "inline-block";

  showQuestion();
}

function showQuestion() {
  const q = questions[current];
  questionEl.textContent = q.q;
  progressEl.textContent = `Question ${current + 1} of ${questions.length}`;
  answerInput.value = "";
}

function checkAnswer() {
  const userAns = answerInput.value.trim().toLowerCase();
  const correct = questions[current].a.toLowerCase();

  if (userAns === correct) {
    feedbackEl.textContent = "✅ Correct!";
    score++;
    current++;

    if (current < questions.length) {
      setTimeout(() => {
        feedbackEl.textContent = "";
        showQuestion();
      }, 1500);
    } else {
      endQuiz();
    }
  } else {
    feedbackEl.textContent = `❌ Wrong! Restarting quiz...`;
    setTimeout(() => {
      startQuiz();
    }, 2000);
  }
}

function endQuiz() {
  questionEl.textContent = "🎉 You finished the quiz!";
  progressEl.textContent = "";
  feedbackEl.textContent = "";
  scoreEl.textContent = `Your score: ${score} / ${questions.length}`;
  answerInput.style.display = "none";
  submitBtn.style.display = "none";
  startBtn.style.display = "inline-block";
  feedbackSection.style.display = "flex";
}

submitFeedbackBtn.addEventListener("click", () => {
  if (userFeedback.value.trim() !== "") {
    thanksMsg.textContent = "✅ Thank you for your feedback!";
    userFeedback.value = "";
  } else {
    thanksMsg.textContent = "⚠️ Please write something first.";
  }
});

startBtn.addEventListener("click", startQuiz);
submitBtn.addEventListener("click", checkAnswer);
