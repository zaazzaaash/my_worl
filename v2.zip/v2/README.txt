Unified_Website - Ready to run with XAMPP

Location: place this folder inside your XAMPP htdocs directory:
C:\xampp\htdocs\Unified_Website\

How to run:
1. Start Apache (and MySQL if projects need DB) in XAMPP.
2. Open your browser and go to: http://localhost/Unified_Website/index.php
3. Use the top-left navbar to open Home / SPT1 / WS101.
4. If the embedded iframe doesn't work for a specific project (headers/sessions), open the project directly:
   - http://localhost/Unified_Website/spt1/None
   - http://localhost/Unified_Website/ws101/None

Detected entry files:
- SPT1 entry: None
- WS101 entry: None

Notes:
- I wrapped each project in a dark-themed layout and used iframes to keep the original project code intact.
- If you want me to inline or refactor specific PHP files into the shared layout (remove iframe), I can do that next — but it may require altering session/header code in each app.
