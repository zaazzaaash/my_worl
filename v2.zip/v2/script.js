
document.addEventListener('DOMContentLoaded', ()=>{
  // Toggle dropdowns on click (only one open)
  document.querySelectorAll('.nav .dropdown > button').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      const parent = btn.parentElement;
      const menu = parent.querySelector('.dropdown-menu');
      // close others
      document.querySelectorAll('.dropdown-menu').forEach(m=>{ if(m!==menu) m.style.display='none'; });
      // toggle this
      menu.style.display = (menu.style.display==='flex')? 'none':'flex';
      e.stopPropagation();
    });
  });
  // Close dropdown when clicking outside
  document.addEventListener('click', ()=>{
    document.querySelectorAll('.dropdown-menu').forEach(m=> m.style.display='none');
  });
  // Handle project open in iframe fullscreen with fade
  document.querySelectorAll('.project-link').forEach(a=>{
    a.addEventListener('click', (e)=>{
      e.preventDefault();
      const href = a.getAttribute('data-href');
      const iframeWrap = document.getElementById('iframeWrap');
      const iframe = document.getElementById('projFrame');
      iframe.src = href;
      iframeWrap.style.display = 'block';
      iframeWrap.classList.remove('fade-in');
      void iframeWrap.offsetWidth;
      iframeWrap.classList.add('fade-in');
      // close dropdowns
      document.querySelectorAll('.dropdown-menu').forEach(m=> m.style.display='none');
      window.scrollTo(0,0);
    });
  });
  // Close iframe when pressing ESC or clicking overlay background (not iframe content)
  document.getElementById('iframeWrap').addEventListener('click', (e)=>{
    if(e.target.id==='iframeWrap' || e.key==='Escape'){
      document.getElementById('projFrame').src='about:blank';
      document.getElementById('iframeWrap').style.display='none';
    }
  });
  document.addEventListener('keydown',(e)=>{ if(e.key==='Escape'){ document.getElementById('projFrame').src='about:blank'; document.getElementById('iframeWrap').style.display='none'; } });
});
