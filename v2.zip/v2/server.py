#!/usr/bin/env python3
"""
Simple HTTP Server for Kingharvey's Projects
Usage: python server.py [port]
Default port: 8000
"""

import http.server
import socketserver
import os
import sys
from pathlib import Path

# Configuration
DEFAULT_PORT = 8000
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """Custom handler with better directory listing and error pages"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)
    
    def end_headers(self):
        # Add security headers
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'SAMEORIGIN')
        self.send_header('X-XSS-Protection', '1; mode=block')
        super().end_headers()
    
    def log_message(self, format, *args):
        # Custom log format with colors
        message = format % args
        sys.stderr.write(f"\033[36m[{self.log_date_time_string()}]\033[0m {message}\n")
    
    def do_GET(self):
        # Serve index.html for root path
        if self.path == '/':
            self.path = '/index.html'
        return super().do_GET()


def find_free_port(start_port, max_attempts=10):
    """Find an available port starting from start_port"""
    port = start_port
    for _ in range(max_attempts):
        try:
            with socketserver.TCPServer(("", port), None) as s:
                return port
        except OSError:
            port += 1
    return None


def print_banner(port, directory):
    """Print startup banner with server info"""
    print("\n" + "="*60)
    print("\033[1;36m  🚀 Kingharvey's Project Server\033[0m")
    print("="*60)
    print(f"\033[32m✓\033[0m Server running on: \033[1mhttp://localhost:{port}\033[0m")
    print(f"\033[32m✓\033[0m Serving directory: \033[1m{directory}\033[0m")
    print("\n\033[33mTips:\033[0m")
    print("  • Press \033[1mCtrl+C\033[0m to stop the server")
    print("  • Your projects should be in 'spt1/' and 'ws101/' folders")
    print("  • Access projects via the web interface")
    print("="*60 + "\n")


def main():
    # Get port from command line or use default
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print(f"\033[31mError:\033[0m Invalid port number: {sys.argv[1]}")
            print("Usage: python server.py [port]")
            sys.exit(1)
    else:
        port = DEFAULT_PORT
    
    # Find available port if specified port is busy
    available_port = find_free_port(port)
    if available_port is None:
        print(f"\033[31mError:\033[0m Could not find an available port")
        sys.exit(1)
    
    if available_port != port:
        print(f"\033[33mWarning:\033[0m Port {port} is busy, using port {available_port} instead")
        port = available_port
    
    # Create server
    try:
        with socketserver.TCPServer(("", port), CustomHTTPRequestHandler) as httpd:
            httpd.allow_reuse_address = True
            print_banner(port, DIRECTORY)
            
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                print("\n\n" + "="*60)
                print("\033[32m✓\033[0m Server stopped gracefully")
                print("="*60 + "\n")
                sys.exit(0)
    
    except PermissionError:
        print(f"\033[31mError:\033[0m Permission denied for port {port}")
        print("Try using a port number above 1024 or run with elevated privileges")
        sys.exit(1)
    except OSError as e:
        print(f"\033[31mError:\033[0m {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()