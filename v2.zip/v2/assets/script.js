
// Minimal script to mark active nav link
document.addEventListener('DOMContentLoaded', ()=>{
  const links = document.querySelectorAll('.navlinks a');
  links.forEach(a=>{
    if(window.location.pathname.endsWith(a.getAttribute('data-file'))){
      a.classList.add('active');
    }
  });
});
