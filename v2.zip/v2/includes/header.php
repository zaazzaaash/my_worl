<?php
// Shared header (dark theme)
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>My Web Projects</title>
  <link rel="stylesheet" href="assets/style.css" />
</head>
<body>
  <header class="header">
    <div class="brand"><div class="dot"></div><div>My Web Projects</div></div>
    <nav class="navlinks">
      <a href="index.php" data-file="index.php">Home</a>
      <a href="spt1.php" data-file="spt1.php">SPT1</a>
      <a href="ws101.php" data-file="ws101.php">WS101</a>
    </nav>
  </header>
  <main class="container">
