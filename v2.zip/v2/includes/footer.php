
  </main>
  <footer class="footer panel">
    Built for class - Run with XAMPP (Place folder inside htdocs). 
  </footer>
  <script src="assets/script.js"></script>
</body>
</html>
