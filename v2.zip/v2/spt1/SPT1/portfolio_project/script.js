// Shared script.js for login, portfolio interactions, validation, welcome animation, logout animation

// LOGIN PAGE LOGIC
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const user = document.getElementById('username').value.trim();
    const pass = document.getElementById('password').value.trim();
    if (user === "admin" && pass === "1234") {
      localStorage.setItem("loggedIn", "true");
      localStorage.setItem("username", user); // save username
      // mark greeted as not set for new session
      sessionStorage.removeItem('greeted');
      window.location.href = "new3.html";
    } else {
      document.getElementById('loginError').textContent = "Invalid username or password!";
    }
  });
}

// PORTFOLIO PAGE LOGIC
if (window.location.pathname.includes("new3.html")) {
  // Redirect if not logged in
  if (localStorage.getItem("loggedIn") !== "true") {
    window.location.href = "index.html";
  }

  // Show welcome greeting with one-time animation per session
  const username = localStorage.getItem("username");
  if (username) {
    const welcome = document.getElementById('welcomeUser');
    if (welcome) {
      const greeted = sessionStorage.getItem("greeted");
      if (!greeted) {
        welcome.textContent = `Welcome back, ${username}! 👋`;
        welcome.classList.add('welcome-animate');
        sessionStorage.setItem("greeted", "true");
      } else {
        welcome.textContent = `Welcome, ${username}! 👋`;
      }
    }
  }

  // Back button
  const backBtn = document.getElementById('backBtn');
  if(backBtn){
    backBtn.addEventListener('click', () => {
      window.history.back();
    });
  }

  // Logout button with goodbye fade effect
  const logoutBtn = document.getElementById('logoutBtn');
  if(logoutBtn){
    logoutBtn.addEventListener('click', () => {
      const goodbye = document.createElement('div');
      goodbye.textContent = "Goodbye 👋";
      goodbye.style.position = "fixed";
      goodbye.style.top = "50%";
      goodbye.style.left = "50%";
      goodbye.style.transform = "translate(-50%, -50%)";
      goodbye.style.fontSize = "3rem";
      goodbye.style.color = "#ff4444";
      goodbye.style.opacity = "0";
      goodbye.style.background = "rgba(0,0,0,0.6)";
      goodbye.style.padding = "1rem 2rem";
      goodbye.style.borderRadius = "10px";
      goodbye.style.zIndex = "9999";
      goodbye.style.transition = "opacity 1.2s ease, transform 1.2s ease";
      document.body.appendChild(goodbye);

      // Fade in and redirect after fade
      setTimeout(() => { goodbye.style.opacity = "1"; goodbye.style.transform = "translate(-50%, -50%) scale(1.02)"; }, 50);
      setTimeout(() => {
        localStorage.removeItem("loggedIn");
        localStorage.removeItem("username");
        sessionStorage.clear();
        window.location.href = "index.html";
      }, 1700);
    });
  }

  // Contact form validation with dynamic feedback
  const form = document.querySelector('#contact form');
  if(form){
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const name = document.getElementById('name');
      const email = document.getElementById('email');
      const message = document.getElementById('message');

      let errors = [];
      if (name.value.trim() === "") errors.push("Name is required.");
      if (!/^\S+@\S+\.\S+$/.test(email.value.trim())) errors.push("Enter a valid email.");
      if (message.value.trim().length < 5) errors.push("Message must be at least 5 characters.");

      let feedback = document.getElementById('formFeedback');
      if (!feedback) {
        feedback = document.createElement('p');
        feedback.id = 'formFeedback';
        feedback.style.marginTop = '1rem';
        feedback.style.fontWeight = 'bold';
        form.appendChild(feedback);
      }

      if (errors.length > 0) {
        feedback.textContent = errors.join(" ");
        feedback.style.color = "crimson";
      } else {
        feedback.textContent = "Message sent successfully!";
        feedback.style.color = "limegreen";
        form.reset();
      }
    });
  }
}
