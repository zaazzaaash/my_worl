-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2025 at 03:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quizsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `choice1` varchar(255) NOT NULL,
  `choice2` varchar(255) NOT NULL,
  `choice3` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`id`, `question`, `choice1`, `choice2`, `choice3`, `answer`) VALUES
(1, 'What does HTML stand for?', 'Hyper Tool Markup Language', 'Hypertext Markup Language', 'HighText Machine Language', 'Hypertext Markup Language'),
(2, 'Which tag is used to link CSS?', 'style', 'link', 'css', 'link'),
(3, 'Which property sets text color in CSS?', 'font-color', 'color', 'text-style', 'color'),
(4, 'What keyword declares a variable in JS?', 'var', 'let', 'const', 'let'),
(5, 'Which HTML tag adds JavaScript?', 'js', 'script', 'code', 'script'),
(6, 'What does CSS stand for?', 'Creative Style System', 'Cascading Style Sheets', 'Computer Styling Structure', 'Cascading Style Sheets'),
(7, 'Which attribute sets an image source in HTML?', 'link', 'src', 'href', 'src'),
(8, 'Which property controls font size in CSS?', 'font', 'font-size', 'text-size', 'font-size'),
(9, 'Which symbol is used for comments in JS?', '<!-- -->', '//', '/* */', '//'),
(10, 'Which tag creates a hyperlink in HTML?', 'a', 'link', 'href', 'a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quizzes`
--
ALTER TABLE `quizzes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
