﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace task2.Controllers
{
    public class AccountController : Controller
    {
        private static List<UserInfo> _users = new List<UserInfo>();

        public class UserInfo
        {
            public string Username { get; set; }
            public string Password { get; set; }
            public string Email { get; set; }
        }

        // GET: Login 
        public IActionResult Login()
        {
            return View();
        }

        // POST: Login 
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ViewBag.Error = "Username and password are required.";
                return View();
            }

            var user = _users.FirstOrDefault(u => u.Username == username && u.Password == password);

            if (user != null)
            {
                HttpContext.Session.SetString("Username", username);
                return RedirectToAction("Dashboard");
            }

            ViewBag.Error = "Invalid username or password.";
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(string username, string password, string confirmPassword, string email)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(email))
            {
                ViewBag.Error = "All fields are required.";
                return View();
            }

            if (password != confirmPassword)
            {
                ViewBag.Error = "Passwords do not match.";
                return View();
            }

            if (_users.Any(u => u.Username == username))
            {
                ViewBag.Error = "Username already exists.";
                return View();
            }

            if (_users.Any(u => u.Email == email))
            {
                ViewBag.Error = "Email already registered.";
                return View();
            }

            _users.Add(new UserInfo
            {
                Username = username,
                Password = password,
                Email = email
            });

            ViewBag.Success = "Registration successful! You can now login.";
            return View("Login");
        }

        // GET: Dashboard (protected page) 
        public IActionResult Dashboard()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("Username")))
            {
                return RedirectToAction("Login");
            }
            return View();
        }

        // User profile page
        public IActionResult Profile()
        {
            var username = HttpContext.Session.GetString("Username");
            if (string.IsNullOrEmpty(username))
            {
                return RedirectToAction("Login");
            }

            // Get user info
            var user = _users.FirstOrDefault(u => u.Username == username);
            if (user == null)
            {
                return RedirectToAction("Login");
            }

            // Get user's rentals
            var userRentals = GetUserRentals(username);
            ViewBag.UserRentals = userRentals;

            return View(user);
        }

        // Update profile
        [HttpPost]
        public IActionResult UpdateProfile(string email, string currentPassword, string newPassword)
        {
            var username = HttpContext.Session.GetString("Username");
            if (string.IsNullOrEmpty(username))
            {
                return RedirectToAction("Login");
            }

            var user = _users.FirstOrDefault(u => u.Username == username);
            if (user == null)
            {
                return RedirectToAction("Login");
            }

            // Verify current password if changing password
            if (!string.IsNullOrEmpty(newPassword))
            {
                if (user.Password != currentPassword)
                {
                    ViewBag.Error = "Current password is incorrect.";
                    ViewBag.UserRentals = GetUserRentals(username);
                    return View("Profile", user);
                }

                user.Password = newPassword;
            }

            // Update email
            if (!string.IsNullOrEmpty(email))
            {
                user.Email = email;
            }

            ViewBag.Success = "Profile updated successfully.";
            ViewBag.UserRentals = GetUserRentals(username);
            return View("Profile", user);
        }

        // Notifications page
        public IActionResult Notifications()
        {
            var username = HttpContext.Session.GetString("Username");
            if (string.IsNullOrEmpty(username))
            {
                return RedirectToAction("Login");
            }

            // Get user's rentals for overdue check
            var userRentals = GetUserRentals(username);
            var overdueBooks = userRentals.Where(r => r.IsOverdue).ToList();
            ViewBag.OverdueBooks = overdueBooks;

            return View();
        }

        // POST: Logout 
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        // Helper method to get user rentals
        private List<LibraryController.Rental> GetUserRentals(string username)
        {
            var userRentalsJson = HttpContext.Session.GetString($"Rentals_{username}");
            return string.IsNullOrEmpty(userRentalsJson)
                ? new List<LibraryController.Rental>()
                : JsonSerializer.Deserialize<List<LibraryController.Rental>>(userRentalsJson);
        }
    }
}