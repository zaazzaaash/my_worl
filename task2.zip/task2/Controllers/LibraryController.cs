﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace task2.Controllers
{
    public class LibraryController : Controller
    {
        // Book catalog page
        public IActionResult Catalog()
        {
            // Initialize books if not exists
            if (HttpContext.Session.GetString("LibraryBooks") == null)
            {
                var books = new List<Book>
        {
            new Book { Id = 1, Title = "Introduction to Programming", Author = "John Smith", IsAvailable = true },
            new Book { Id = 2, Title = "Data Structures and Algorithms", Author = "Jane Doe", IsAvailable = true },
            new Book { Id = 3, Title = "Web Development Basics", Author = "Alan Turing", IsAvailable = true },
            new Book { Id = 4, Title = "Database Systems", Author = "Edgar Codd", IsAvailable = true },
            new Book { Id = 5, Title = "Computer Networks", Author = "Tim Berners-Lee", IsAvailable = true },
            new Book { Id = 6, Title = "Software Engineering", Author = "Grace Hopper", IsAvailable = true }
        };
                HttpContext.Session.SetString("LibraryBooks", JsonSerializer.Serialize(books));
            }

            var booksJson = HttpContext.Session.GetString("LibraryBooks");
            var books = JsonSerializer.Deserialize<List<Book>>(booksJson);

            // Pass the books to the view
            return View(books);
        }

        // Rent a book
        [HttpPost]
        public IActionResult RentBook(int bookId)
        {
            var username = HttpContext.Session.GetString("Username");
            if (string.IsNullOrEmpty(username))
            {
                return RedirectToAction("Login", "Account");
            }

            // Get user's current rentals
            var userRentals = GetUserRentals(username);

            // Check if user has reached rental limit (3 books)
            if (userRentals.Count >= 3)
            {
                TempData["Error"] = "You have reached the maximum rental limit of 3 books.";
                return RedirectToAction("Catalog");
            }

            // Get books
            var booksJson = HttpContext.Session.GetString("LibraryBooks");
            var books = JsonSerializer.Deserialize<List<Book>>(booksJson);
            var book = books.FirstOrDefault(b => b.Id == bookId);

            if (book == null || !book.IsAvailable)
            {
                TempData["Error"] = "Book is not available for rental.";
                return RedirectToAction("Catalog");
            }

            // Update book status
            book.IsAvailable = false;
            HttpContext.Session.SetString("LibraryBooks", JsonSerializer.Serialize(books));

            // Create rental record
            var rental = new Rental
            {
                BookId = bookId,
                BookTitle = book.Title,
                RentalDate = DateTime.Now,
                DueDate = DateTime.Now.AddDays(14)
            };

            userRentals.Add(rental);
            HttpContext.Session.SetString($"Rentals_{username}", JsonSerializer.Serialize(userRentals));

            TempData["Success"] = $"You have successfully rented '{book.Title}'.";
            return RedirectToAction("Catalog");
        }

        // Return a book
        [HttpPost]
        public IActionResult ReturnBook(int bookId)
        {
            var username = HttpContext.Session.GetString("Username");
            if (string.IsNullOrEmpty(username))
            {
                return RedirectToAction("Login", "Account");
            }

            // Get user's rentals
            var userRentals = GetUserRentals(username);
            var rental = userRentals.FirstOrDefault(r => r.BookId == bookId);

            if (rental != null)
            {
                userRentals.Remove(rental);
                HttpContext.Session.SetString($"Rentals_{username}", JsonSerializer.Serialize(userRentals));

                // Update book status
                var booksJson = HttpContext.Session.GetString("LibraryBooks");
                var books = JsonSerializer.Deserialize<List<Book>>(booksJson);
                var book = books.FirstOrDefault(b => b.Id == bookId);

                if (book != null)
                {
                    book.IsAvailable = true;
                    HttpContext.Session.SetString("LibraryBooks", JsonSerializer.Serialize(books));
                }

                TempData["Success"] = $"You have returned '{rental.BookTitle}'.";
            }

            return RedirectToAction("Profile", "Account");
        }

        // Helper method to get user rentals
        private List<Rental> GetUserRentals(string username)
        {
            var userRentalsJson = HttpContext.Session.GetString($"Rentals_{username}");
            return string.IsNullOrEmpty(userRentalsJson)
                ? new List<Rental>()
                : JsonSerializer.Deserialize<List<Rental>>(userRentalsJson);
        }

        public class Book
        {
            public int Id { get; set; }
            public string Title { get; set; }
            public string Author { get; set; }
            public bool IsAvailable { get; set; }
        }

        public class Rental
        {
            public int BookId { get; set; }
            public string BookTitle { get; set; }
            public DateTime RentalDate { get; set; }
            public DateTime DueDate { get; set; }
            public bool IsOverdue => DueDate < DateTime.Now;
        }
    }
}